function derivar=derivar (x)
% function derivar=derivar (x)
% Funci�n que deriva una funci�n introducida como par�metro.
% PARAMETROS DE ENTRADA:
%               x:  se�al a derivar.
% PARAMETROS DE SALIDA:
%               deriva: se�al de entrada derivada.

derivar=diff(x);

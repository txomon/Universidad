function y = plot_pr(m)
% Informa al usuario que se visualizar�n 'm' figuras
% y que se deber� pulsar cualquier techa para avanzar a la siguiente.

fprintf(['\n\nHay ',int2str(m),' figuras para visualizar.\n']);
fprintf('Se deber� pulsar cualquier tecla para avanzar a la siguiente.\n');
pause;




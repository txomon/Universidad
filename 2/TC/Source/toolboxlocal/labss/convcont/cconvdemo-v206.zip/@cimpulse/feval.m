function y = feval(sig,t)
y = sig.Area * ( sig.Delay==t );
